import java.applet.*;
import java.awt.*;


public class binaryAdd extends Applet
{
  private Label lTitle = new Label("Binary Addition Algorithm");
  private Label lCarry = new Label("Carry:", Label.RIGHT);
  private Label lAddX  = new Label("    X:", Label.RIGHT);
  private Label lAddY  = new Label("    Y:", Label.RIGHT);
  private Label lSum   = new Label("  Sum:", Label.RIGHT);

  private noClickButton[] bCarry  = new noClickButton[9];
  private noClickButton   bDummyX = new noClickButton(" ");
  private Button[]        bAddX   = new Button[8];
  private noClickButton   bDummyY = new noClickButton(" ");
  private Button[]        bAddY   = new Button[8];
  private noClickButton[] bSum    = new noClickButton[9];
  private Button          bDoIt   = new Button("ADD");
  private Button          bStep   = new Button("Single Step");

  private Panel pAll   = new Panel();
  private Panel pTitle = new Panel();
  private Panel pCarry = new Panel();
  private Panel pAddX  = new Panel();
  private Panel pAddY  = new Panel();
  private Panel pSum   = new Panel();
  private Panel pDoIt  = new Panel();

  private int   place = 0;

	public binaryAdd()
	{

	}

	public String getAppletInfo()
	{
		return "Name: binaryAdd\r\n" +
		       "Author: Bradley Kjell\r\n" +
		       "Created with Microsoft Visual J++ Version 1.0";
	}


	public void init()
	{
 		resize(320, 220);
    setFont( new Font("Courier", Font.PLAIN, 12 ) );

    pAll.setLayout( new GridLayout(6,1) );

    pTitle.add( lTitle );

    pCarry.add( lCarry );
    for ( int i = 8; i>=0; i-- ) 
    {
      bCarry[i] = new noClickButton(" ");
      pCarry.add( bCarry[i] );
    }

    pAddX.add( lAddX );
    pAddX.add( bDummyX );
    for ( int i = 7; i>=0; i-- ) 
    {
      bAddX[i] = new Button("0");
      pAddX.add( bAddX[i] );
    }
    
    pAddY.add( lAddY );
    pAddY.add( bDummyY);
    for ( int i = 7; i>=0; i-- ) 
    {
      bAddY[i] = new Button("0");
      pAddY.add( bAddY[i] );
    }

    pSum.add( lSum );
    for ( int i = 8; i>=0; i-- ) 
    {
      bSum[i] = new noClickButton(" ");
      pSum.add( bSum[i] );
    }

    pDoIt.add( bDoIt );
    pDoIt.add( bStep );
    
    pAll.add( pTitle );
    pAll.add( pCarry );
    pAll.add( pAddX );
    pAll.add( pAddY );
    pAll.add( pSum );
    pAll.add( pDoIt );

    add( pAll );

	}

	public void destroy()
	{
	}

	public void paint(Graphics g)
	{
    Dimension d = size();
    g.drawLine( 0, 0, d.width-1, 0); 
    g.drawLine( d.width-1, 0, d.width-1, d.height-1); 
    g.drawLine( d.width-1, d.height-1, 0, d.height-1); 
    g.drawLine( 0, d.height-1, 0, 0); 
 
    g.drawLine( 2, 2, d.width-3, 2); 
    g.drawLine( d.width-3, 2, d.width-3, d.height-3); 
    g.drawLine( d.width-3, d.height-3, 2, d.height-3); 
    g.drawLine( 2, d.height-3, 2, 2); 
	}

	public void start()
	{
	}
	
	public void stop()
	{
	}

  private void clearResults()
  {
    for ( int i = 0; i<8; i++ )
    {
      bCarry[i].setLabel(" ");
      bSum  [i].setLabel(" ");
    }
    bCarry[8].setLabel(" ");
  }

  public boolean action( Event event, Object obj)
  {
    if ( event.target instanceof noClickButton ) 
      return true;

    if ( event.target instanceof Button )
    {
      Button b = (Button)event.target;

      if ( b.getLabel().compareTo("Single Step") == 0 )
      {
        if ( place > 7 )
          place = 0;
        if ( place == 0 )
          clearResults();

        AddStep( place );
        place++ ;
        return true;
      }

      place = 0;
      clearResults();

      if ( b.getLabel().compareTo("0") == 0 )
      {
        b.setLabel("1");
        return true;
      }
      if ( b.getLabel().compareTo("1") == 0 )
      {
        b.setLabel("0");
        return true;
      }

      if ( b.getLabel().compareTo("ADD") == 0 )
      {
        AddUp();
        place = 0;
        return true;
      }


    }
    
    return true;
  }


  private int buttonToBit( Button b )
  {
    if ( b.getLabel().compareTo("0") == 0 ) return 0;
    if ( b.getLabel().compareTo(" ") == 0 ) return 0;
    return 1;
  }

  private void AddUp()
  {
    for ( int place = 0; place<8; place++ )
    {
      try
      {
        Thread.sleep( 300 );
      }
      catch( Exception e )
      {
      }
      AddStep( place );
    }
  }

  private void AddStep( int place )
  {
    int carry, x, y, carryOut, sum;

    carry = buttonToBit( bCarry[place] );
    x     = buttonToBit( bAddX [place] );
    y     = buttonToBit( bAddY [place] );

    sum = x+y+carry;
    if ( sum == 0 )
    {
      bSum[place].setLabel("0");
      bCarry[place+1].setLabel("0");
    }
    else if ( sum == 1 )
    {
      bSum[place].setLabel("1");
      bCarry[place+1].setLabel("0");
    }
    else if ( sum == 2 )
    {
      bSum[place].setLabel("0");
      bCarry[place+1].setLabel("1");
    }
    else if ( sum == 3 )
    {
      bSum[place].setLabel("1");
      bCarry[place+1].setLabel("1");
    }

  }

}

class noClickButton extends Button
{
  noClickButton( String s )
  {
    super( s );
  }

}